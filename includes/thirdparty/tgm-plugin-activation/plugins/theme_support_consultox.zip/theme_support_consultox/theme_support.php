<?php
/*
Plugin Name: Theme Support
Plugin URI: http://themeforest.net/
Description: This plugin is compatible with this wordpress themes. 
Author: Muhibbur Rashid
Author URI: http://themebunch.com
Version: 1.0
Text Domain: BUNCH_NAME
*/
if( !defined( 'BUNCH_TH_ROOT' ) ) define('BUNCH_TH_ROOT', plugin_dir_path( __FILE__ ));
if( !defined( 'BUNCH_TH_URL' ) ) define( 'BUNCH_TH_URL', plugins_url( '', __FILE__ ) );
if( !defined( 'BUNCH_NAME' ) ) define( 'BUNCH_NAME', 'consultox' );
include_once( 'includes/loader.php' );
function consultox_bunch_widget_init2()
{
	global $wp_registered_sidebars;
	$theme_options = _WSH()->option();
	if( class_exists( 'Bunch_Recent_News' ) )register_widget( 'Bunch_Recent_News' );
	if( class_exists( 'Bunch_Services_Menu' ) )register_widget( 'Bunch_Services_Menu' );
	if( class_exists( 'Bunch_Brochures' ) )register_widget( 'Bunch_Brochures' );
	if( class_exists( 'Bunch_Get_In_Touch' ) )register_widget( 'Bunch_Get_In_Touch' );
	if( class_exists( 'Bunch_About_Us' ) )register_widget( 'Bunch_About_Us' );
	if( class_exists( 'Bunch_NewsLetter' ) )register_widget( 'Bunch_NewsLetter' );
}
add_action( 'widgets_init', 'consultox_bunch_widget_init2' );