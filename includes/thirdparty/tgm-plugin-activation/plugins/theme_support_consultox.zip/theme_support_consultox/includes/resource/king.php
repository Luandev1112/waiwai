<?php
/**
 * Kingcomposer array
 *
 * @package Student WP
 * @author Shahbaz Ahmed <shahbazahmed9@hotmail.com>
 * @version 1.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	die( 'Restricted' );
}
$rvslider = array(
				'type'			=> 'dropdown',
				'label'			=> esc_html__('Choose Slider', BUNCH_NAME ),
				'name'			=> 'slider_slug',
				'options'		=> bunch_get_rev_slider( 0 ),
				'description'	=> esc_html__('Choose Slider', BUNCH_NAME ),
			);
$text_limit = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Text Limit', BUNCH_NAME ),
				"name"			=>	"text_limit",
				"description"	=>	esc_html__('Enter text limit of posts to Show.', BUNCH_NAME ),
			);
$number = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Number', BUNCH_NAME ),
				"name"			=>	"num",
				"description"	=>	esc_html__('Enter Number of posts to Show.', BUNCH_NAME )
			);
$orderby = array(
				"type"			=>	"select",
				"label"			=>	esc_html__("Order By", BUNCH_NAME),
				"name"			=>	"sort",
				'options'		=>	array('date'=>esc_html__('Date', BUNCH_NAME),'title'=>esc_html__('Title', BUNCH_NAME) ,'name'=>esc_html__('Name', BUNCH_NAME), 'author'			=>	esc_html__('Author', BUNCH_NAME),'comment_count' =>esc_html__('Comment Count', BUNCH_NAME),'random' =>esc_html__('Random', BUNCH_NAME) ),
				"description"	=>	esc_html__("Enter the sorting order.", BUNCH_NAME)
			);
$order = array(
				"type"			=>	"select",
				"label"			=>	esc_html__("Order", BUNCH_NAME),
				"name"			=>	"order",
				'options'		=>	(array('ASC'=>esc_html__('Ascending', BUNCH_NAME),'DESC'=>esc_html__('Descending', BUNCH_NAME) ) ),			
				"description"	=>	esc_html__("Enter the sorting order.", BUNCH_NAME)
			);
$name = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Name', BUNCH_NAME ),
				"name"			=>	"name",
				"description"	=>	esc_html__('Enter section name.', BUNCH_NAME )
			);
$designation = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Designation', BUNCH_NAME ),
				"name"			=>	"designation",
				"description"	=>	esc_html__('Enter the designation.', BUNCH_NAME )
			);
$title = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Title', BUNCH_NAME ),
				"name"			=>	"title",
				"description"	=>	esc_html__('Enter section title.', BUNCH_NAME )
			);
$subtitle = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Sub-Title', BUNCH_NAME ),
				"name"			=>	"subtitle",
				"description"	=>	esc_html__('Enter section subtitle.', BUNCH_NAME )
			);
$text = array(
				"type"			=>	"textarea",
				"label"			=>	esc_html__('Text', BUNCH_NAME ),
				"name"			=>	"text",
				"description"	=>	esc_html__('Enter text to show.', BUNCH_NAME )
			);
$text_list = array(
				"type"			=>	"textarea",
				"label"			=>	esc_html__('Text List', BUNCH_NAME ),
				"name"			=>	"text_list",
				"description"	=>	esc_html__('Enter listing to show.', BUNCH_NAME )
			);
$editor  = array(
				"type"			=>	"editor",
				"label"			=>	esc_html__('Title', BUNCH_NAME ),
				"name"			=>	"editor",
				"description"	=>	esc_html__('Enter title to show.', BUNCH_NAME )
			);
$email = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Email', BUNCH_NAME ),
				"name"			=>	"email",
				"description"	=>	esc_html__('Enter email.', BUNCH_NAME )
			);
$phone = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Phone', BUNCH_NAME ),
				"name"			=>	"phone",
				"description"	=>	esc_html__('Enter phone.', BUNCH_NAME )
			);
$address = array(
				"type"			=>	"textarea",
				"label"			=>	esc_html__('Address', BUNCH_NAME ),
				"name"			=>	"address",
				"description"	=>	esc_html__('Enter address.', BUNCH_NAME )
			);
$website = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Website', BUNCH_NAME ),
				"name"			=>	"website",
				"description"	=>	esc_html__('Enter website.', BUNCH_NAME )
			);
$working_hours = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Working Hours', BUNCH_NAME ),
				"name"			=>	"working_hours",
				"description"	=>	esc_html__('Enter Working Hours.', BUNCH_NAME )
			);
$contact_title = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Contact Us Title', BUNCH_NAME ),
				"name"			=>	"contact_title",
				"description"	=>	esc_html__('Enter contact us title.', BUNCH_NAME )
			);
$contact_text = array(
				"type"			=>	"textarea",
				"label"			=>	esc_html__('Contact Us Description', BUNCH_NAME ),
				"name"			=>	"contact_text",
				"description"	=>	esc_html__('Enter contact us description.', BUNCH_NAME )
			);
$contact_shortcode = array(
				"type"			=>	"textarea",
				"label"			=>	esc_html__('Contact Us Shortcode', BUNCH_NAME ),
				"name"			=>	"contact_shortcode",
				"description"	=>	esc_html__('Enter contact us shortcode to show.', BUNCH_NAME )
			);
$latitude = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Latitude', BUNCH_NAME ),
				"name"			=>	"latitude",
				"description"	=>	esc_html__('Enter latitude.', BUNCH_NAME )
			);
$longitude = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Longitude', BUNCH_NAME ),
				"name"			=>	"longitude",
				"description"	=>	esc_html__('Enter longitude.', BUNCH_NAME )
			);
$zoom = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Map Zoom', BUNCH_NAME ),
				"name"			=>	"zoom",
				"description"	=>	esc_html__('Enter map zoom.', BUNCH_NAME ),
				'value'			=>	'12',
			);
$btn_title = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Button Title', BUNCH_NAME ),
				"name"			=>	"btn_title",
				"description"	=>	esc_html__('Enter section Button title.', BUNCH_NAME )
			);
$btn_link = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Button Link', BUNCH_NAME ),
				"name"			=>	"btn_link",
				"description"	=>	esc_html__('Enter section Button Link.', BUNCH_NAME ),
				'value'			=>	'#',
			);
$img = array(
				"type"			=>	"attach_image_url",
				"label"			=>	esc_html__('Image', BUNCH_NAME ),
				"name"			=>	"img",
				'admin_label' 	=> 	false,
				"description"	=>	esc_html__('Choose Image.', BUNCH_NAME )
			);
$bg_img = array(
				"type"			=>	"attach_image_url",
				"label"			=>	esc_html__('Background Image', BUNCH_NAME ),
				"name"			=>	"bg_img",
				'admin_label' 	=> 	false,
				"description"	=>	esc_html__('Choose Background image.', BUNCH_NAME )
			);
$multi_img = array(
				"type"			=>	"attach_images",
				"label"			=>	esc_html__('Multi Images', BUNCH_NAME ),
				"name"			=>	"multi_img",
				'admin_label' 	=> 	false,
				"description"	=>	esc_html__('Uplod multi images.', BUNCH_NAME )
			);
$signature = array(
				"type"			=>	"attach_image_url",
				"label"			=>	esc_html__('Signature', BUNCH_NAME ),
				"name"			=>	"signature",
				"description"	=>	esc_html__('Choose Signature.', BUNCH_NAME )
			);
$video_url = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Video URL', BUNCH_NAME ),
				"name"			=>	"video_url",
				'admin_label' 	=> 	false,
				"description"	=>	esc_html__('Enter video url.', BUNCH_NAME )
			);
$video_img = array(
				"type"			=>	"attach_image_url",
				"label"			=>	esc_html__('Video Image', BUNCH_NAME ),
				"name"			=>	"video_img",
				'admin_label' 	=> 	false,
				"description"	=>	esc_html__('Choose video image.', BUNCH_NAME )
			);
$video_text = array(
				"type"			=>	"textarea",
				"label"			=>	esc_html__('Video Description', BUNCH_NAME ),
				"name"			=>	"video_text",
				'admin_label' 	=> 	false,
				"description"	=>	esc_html__('Enter video Description.', BUNCH_NAME )
			);
$icon = array(
				'type'			=>	'icon_picker',
				'label'			=>	esc_html__('Icon', BUNCH_NAME ),
				'name'			=>	'icon',
				'description'	=>	esc_html__('Enter your icon', BUNCH_NAME )
			);
$url = array(
				'type'			=>	'text',
				'label'			=>	esc_html__('URL', BUNCH_NAME ),
				'name'			=>	'url',
				'description'	=>	esc_html__('Enter url', BUNCH_NAME ),
				'value'			=>	'#',
			);
$ff_start = array(
				'type'			=>	'text',
				'label'			=>	esc_html__('Counter Start', BUNCH_NAME ),
				'name'			=>	'ff_start',
				'description'	=>	esc_html__('Enter Counter Start', BUNCH_NAME ),
				'value'			=>	'0',
			);
$ff_stop = array(
				'type'			=>	'text',
				'label'			=>	esc_html__('Counter Stop', BUNCH_NAME ),
				'name'			=>	'ff_stop',
				'description'	=>	esc_html__('Enter Counter Stop', BUNCH_NAME )
			);
$ff_sign = array(
				'type'			=>	'text',
				'label'			=>	esc_html__('Counter Sign', BUNCH_NAME ),
				'name'			=>	'ff_sign',
				'description'	=>	esc_html__('Enter Counter Sign', BUNCH_NAME ),
			);
$newsletter_title = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Newsletter Title', BUNCH_NAME ),
				"name"			=>	"newsletter_title",
				"description"	=>	esc_html__('Enter Newsletter Title.', BUNCH_NAME ),
			);
$newsletter_id = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Newsletter ID', BUNCH_NAME ),
				"name"			=>	"newsletter_id",
				"description"	=>	esc_html__('Choose Newsletter ID.', BUNCH_NAME ),
				'value'			=>	'#',
			);
$newsletter_text = array(
				"type"			=>	"textarea",
				"label"			=>	esc_html__('Newsletter Text', BUNCH_NAME ),
				"name"			=>	"newsletter_text",
				"description"	=>	esc_html__('Choose Newsletter Text.', BUNCH_NAME ),
			);
$date = array(
				'type'			=>	'text',
				'label'			=>	esc_html__('Date', BUNCH_NAME ),
				'name'			=>	'date',
				'description'	=>	esc_html__('Enter Date', BUNCH_NAME )
			);
$cat = array(
				"type"			=>	"dropdown",
				"label"			=>	__('Category', BUNCH_NAME),
				"name"			=>	"cat",
				"options"		=>	 bunch_get_categories(array('taxonomy' =>	'category'), true),
				"description"	=>	__('Choose Category.', BUNCH_NAME)
			);
$services_cat = array(
				"type"			=>	"dropdown",
				"label"			=>	__( 'Category', BUNCH_NAME),
				"name"			=>	"cat",
				"options"		=>	 bunch_get_categories(array( 'taxonomy' =>	'services_category'), true),
				"description"	=>	__( 'Choose Category.', BUNCH_NAME)
			);
$projects_cat = array(
				"type"			=>	"dropdown",
				"label"			=>	__( 'Category', BUNCH_NAME),
				"name"			=>	"cat",
				"options"		=>	 bunch_get_categories(array( 'taxonomy' =>	'projects_category'), true),
				"description"	=>	__( 'Choose Category.', BUNCH_NAME)
			);
$team_cat = array(
				"type"			=>	"dropdown",
				"label"			=>	__( 'Category', BUNCH_NAME),
				"name"			=>	"cat",
				"options"		=>	 bunch_get_categories(array( 'taxonomy' =>	'team_category'), true),
				"description"	=>	__( 'Choose Category.', BUNCH_NAME)
			);
$testimonials_cat = array(
				"type"			=>	"dropdown",
				"label"			=>	__( 'Category', BUNCH_NAME),
				"name"			=>	"cat",
				"options"		=>	 bunch_get_categories(array( 'taxonomy' =>	'testimonials_category'), true),
				"description"	=>	__( 'Choose Category.', BUNCH_NAME)
			);
$faqs_cat = array(
				"type"			=>	"dropdown",
				"label"			=>	__( 'Category', BUNCH_NAME),
				"name"			=>	"cat",
				"options"		=>	 bunch_get_categories(array( 'taxonomy' =>	'faqs_category'), true),
				"description"	=>	__( 'Choose Category.', BUNCH_NAME)
			);
$exclude_cats = array(
			   "type"			=>	"textfield",
			   "label"			=>	__('Excluded Categories ID', BUNCH_NAME ),
			   "name"			=>	"exclude_cats",
			   "description"	=>	__('Enter Excluded Categories ID seperated by commas(13,14).', BUNCH_NAME )
			);
$options = array();

//Revslider
$options['bunch_revslider'] = array(
					'name' => esc_html__('Revslider', BUNCH_NAME),
					'base' => 'bunch_revslider',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show Revolution slider.', BUNCH_NAME),
					'params' => array(
						$rvslider
					),
			);
//Welcome Services
$options['bunch_welcome_services'] = array(
					'name' => esc_html__('Welcome Services', BUNCH_NAME),
					'base' => 'bunch_welcome_services',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Welcome Services.', BUNCH_NAME),
					'params' => array(
						$bg_img,
						$title,
						$text,
						$text_limit,
						$number,
						$services_cat,
						$orderby,
						$order,
					),
			);
//Services Offer
$options['bunch_services_offer'] = array(
					'name' => esc_html__('Services Offer', BUNCH_NAME),
					'base' => 'bunch_services_offer',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Services Offer.', BUNCH_NAME),
					'params' => array(
						$title,
						$text,
						$text_limit,
						$number,
						$services_cat,
						$orderby,
						$order,
					),
			);
//Call to Action
$options['bunch_call_to_action'] = array(
					'name' => esc_html__('Call to Action', BUNCH_NAME),
					'base' => 'bunch_call_to_action',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Call to Action.', BUNCH_NAME),
					'params' => array(
						$bg_img,
						$text,
						$phone,
						$btn_title,
						$btn_link,
					),
			);
//Recent Case
$options['bunch_recent_case'] = array(
					'name' => esc_html__('Recent Case', BUNCH_NAME),
					'base' => 'bunch_recent_case',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Recent Case.', BUNCH_NAME),
					'params' => array(
						array(
							"type"   => "checkbox",
							"label"   => esc_html__('Show/Hide Background Color', BUNCH_NAME ),
							"name"   => "bg_color",
							'options' => array(
								'show_hide' => 'Show/Hide',
							),
							"description" => esc_html__('Choose whether you want to Show/Hide Background Color.', BUNCH_NAME  )
						),
						$title,
						$subtitle,
						$text,
						$video_img,
						$video_url,
						$btn_title,
						$btn_link,
					),
			);
//Our Cases 1
$options['bunch_our_cases_1'] = array(
					'name' => esc_html__('Our Cases 1', BUNCH_NAME),
					'base' => 'bunch_our_cases_1',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show Our Cases 1.', BUNCH_NAME),
					'params' => array(
						$title,
						array(
							'type' => 'group',
							'label' => esc_html__( 'Cases Tab', BUNCH_NAME ),
							'name' => 'product_tabs',
							'description' => esc_html__( 'Enter Cases Tab Info.', BUNCH_NAME ),
							'params' => array(
								$title,
								$number,
								$projects_cat,
								$order,
								$orderby,
							),
						),
					),
			);
//Testimonials 1
$options['bunch_testimonials_1'] = array(
					'name' => esc_html__('Testimonials 1', BUNCH_NAME),
					'base' => 'bunch_testimonials',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show Testimonials 1.', BUNCH_NAME),
					'params' => array(
						$bg_img,
						$text_limit,
						$number,
						$testimonials_cat,
						$orderby,
						$order,
					),
			);
//Latest News
$options['bunch_latest_news'] = array(
					'name' => esc_html__('Latest News', BUNCH_NAME),
					'base' => 'bunch_latest_news',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Latest News.', BUNCH_NAME),
					'params' => array(
						//Tabs Start
						esc_html__( 'General', BUNCH_NAME ) => array(
							$title,
						),
						//Tabs Start
						esc_html__( 'News Left', BUNCH_NAME ) => array(
							$text_limit,
							$number,
							$cat,
							$orderby,
							$order,
						),
						//Tabs Start
						esc_html__( 'News Right', BUNCH_NAME ) => array(
							array(
								"type"			=>	"text",
								"label"			=>	esc_html__('Number', BUNCH_NAME ),
								"name"			=>	"num1",
								"description"	=>	esc_html__('Enter Number of posts to Show.', BUNCH_NAME )
							),
							array(
								"type" => "dropdown",
								"label" => __('Category', BUNCH_NAME),
								"name" => "cat1",
								"options" =>  bunch_get_categories(array('taxonomy' => 'category'), true),
								"description" => __('Choose Category.', BUNCH_NAME)
							),
							array(
								"type"			=>	"select",
								"label"			=>	esc_html__("Order By", BUNCH_NAME),
								"name"			=>	"sort1",
								'options'		=>	array('date'=>esc_html__('Date', BUNCH_NAME),'title'=>esc_html__('Title', BUNCH_NAME) ,'name'=>esc_html__('Name', BUNCH_NAME) ,'author'=>esc_html__('Author', BUNCH_NAME),'comment_count' =>esc_html__('Comment Count', BUNCH_NAME),'random' =>esc_html__('Random', BUNCH_NAME) ),
								"description"	=>	esc_html__("Enter the sorting order.", BUNCH_NAME)
							),
							array(
								"type"			=>	"select",
								"label"			=>	esc_html__("Order", BUNCH_NAME),
								"name"			=>	"order1",
								'options'		=>	(array('ASC'=>esc_html__('Ascending', BUNCH_NAME),'DESC'=>esc_html__('Descending', BUNCH_NAME) ) ),			
								"description"	=>	esc_html__("Enter the sorting order.", BUNCH_NAME)
							),
						),
					),
			);
//Clients
$options['bunch_clients'] = array(
					'name' => esc_html__('Clients', BUNCH_NAME),
					'base' => 'bunch_clients',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-users',
					'description' => esc_html__('Show Clients Logo images.', BUNCH_NAME),
					'params' => array(
						array(
							"type"   => "checkbox",
							"label"   => esc_html__('Show/Hide White Background', BUNCH_NAME ),
							"name"   => "bg_color",
							'options' => array(
								'show_hide' => 'Show/Hide',
							),
							"description" => esc_html__('Choose whether you want to Show/Hide White Background.', BUNCH_NAME  )
						),
						array(
							'type' => 'group',
							'label' => esc_html__( 'Clients Logo', BUNCH_NAME ),
							'name' => 'clients',
							'description' => esc_html__( 'Enter Clients Logo', BUNCH_NAME ),
							'params' => array(
								$title,
								$img,
								$url,
							),
						),
					),
			);
//Get Appointment
$options['bunch_get_appointment'] = array(
					'name' => esc_html__('Get Appointment', BUNCH_NAME),
					'base' => 'bunch_get_appointment',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Get Appointment.', BUNCH_NAME),
					'params' => array(
						$bg_img,
						$title,
						$text,
						$btn_title,
						$btn_link,
					),
			);
//Welcome Services and Form
$options['bunch_welcome_services_form'] = array(
					'name' => esc_html__('Welcome Services and Form', BUNCH_NAME),
					'base' => 'bunch_welcome_services_form',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Welcome Services and Form.', BUNCH_NAME),
					'params' => array(
						//Tabs Start
						esc_html__( 'General', BUNCH_NAME ) => array(
							$editor,
							$text,
							$btn_title,
							$btn_link,
							$text_limit,
							$number,
							$services_cat,
							$orderby,
							$order,
						),
						//Tabs Start
						esc_html__( 'Form', BUNCH_NAME ) => array(
							$contact_title,
							$contact_text,
							$contact_shortcode,
						),
					),
			);
//Our Cases 2
$options['bunch_our_cases_2'] = array(
					'name' => esc_html__('Our Cases 2', BUNCH_NAME),
					'base' => 'bunch_our_cases_2',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show Our Cases 2.', BUNCH_NAME),
					'params' => array(
						$title,
						array(
							'type' => 'group',
							'label' => esc_html__( 'Cases Tab', BUNCH_NAME ),
							'name' => 'product_tabs',
							'description' => esc_html__( 'Enter Cases Tab Info.', BUNCH_NAME ),
							'params' => array(
								$title,
								$number,
								$projects_cat,
								$order,
								$orderby,
							),
						),
					),
			);
//Company CEO Message
$options['bunch_company_ceo_message'] = array(
					'name' => esc_html__('Company CEO Message', BUNCH_NAME),
					'base' => 'bunch_company_ceo_message',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show Company CEO Message.', BUNCH_NAME),
					'params' => array(
						$img,
						$title,
						$text,
						$signature,
					),
			);
//Our Advisors 1
$options['bunch_our_advisors_1'] = array(
					'name' => esc_html__('Our Advisors 1', BUNCH_NAME),
					'base' => 'bunch_our_advisors_1',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-users',
					'description' => esc_html__('Show Our Advisors 1.', BUNCH_NAME),
					'params' => array(
						$title,
						$text,
						$number,
						$team_cat,
						$orderby,
						$order,
					),
			);
//What We Do
$options['bunch_what_we_do'] = array(
					'name' => esc_html__('What We Do', BUNCH_NAME),
					'base' => 'bunch_what_we_do',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show What We Do.', BUNCH_NAME),
					'params' => array(
						$title,
						$text,
						$btn_title,
						$btn_link,
						$number,
						$services_cat,
						$orderby,
						$order,
					),
			);
//Our Company and FAQs
$options['bunch_our_company_faqs'] = array(
					'name' => esc_html__('Our Company and FAQs', BUNCH_NAME),
					'base' => 'bunch_our_company_faqs',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Our Company and FAQs.', BUNCH_NAME),
					'params' => array(
						//Tabs Start
						esc_html__( 'General', BUNCH_NAME ) => array(
							$title,
							array(
								"type"			=>	"attach_image_url",
								"label"			=>	esc_html__('Image Left', BUNCH_NAME ),
								"name"			=>	"img_left",
								'admin_label' 	=> 	false,
								"description"	=>	esc_html__('Choose Image Left.', BUNCH_NAME )
							),
							array(
								"type"			=>	"attach_image_url",
								"label"			=>	esc_html__('Image Right', BUNCH_NAME ),
								"name"			=>	"img_right",
								'admin_label' 	=> 	false,
								"description"	=>	esc_html__('Choose Image Right.', BUNCH_NAME )
							),
							$subtitle,
							$text,
							$text_list,
						),
						//Tabs Start
						esc_html__( 'FAQs', BUNCH_NAME ) => array(
							array(
								"type"			=>	"text",
								"label"			=>	esc_html__('Title', BUNCH_NAME ),
								"name"			=>	"title1",
								"description"	=>	esc_html__('Enter section title.', BUNCH_NAME )
							),
							$text_limit,
							$number,
							$faqs_cat,
							$orderby,
							$order,
						),
					),
			);
//Request a Call Back
$options['bunch_request_callback'] = array(
					'name' => esc_html__('Request a Call Back', BUNCH_NAME),
					'base' => 'bunch_request_callback',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show Request a Call Back.', BUNCH_NAME),
					'params' => array(
						$bg_img,
						$contact_title,
						$contact_shortcode,
					),
			);
//Message From CEO
$options['bunch_message_from_ceo'] = array(
					'name' => esc_html__('Message From CEO', BUNCH_NAME),
					'base' => 'bunch_message_from_ceo',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show Message From CEO.', BUNCH_NAME),
					'params' => array(
						$title,
						$subtitle,
						array(
							"type"			=>	"textarea",
							"label"			=>	esc_html__('Text Left', BUNCH_NAME ),
							"name"			=>	"text_left",
							"description"	=>	esc_html__('Enter left text to show.', BUNCH_NAME )
						),
						array(
							"type"			=>	"textarea",
							"label"			=>	esc_html__('Text Right', BUNCH_NAME ),
							"name"			=>	"text_right",
							"description"	=>	esc_html__('Enter right text to show.', BUNCH_NAME )
						),
						$text_list,
					),
			);
//Our Advisors 2
$options['bunch_our_advisors_2'] = array(
					'name' => esc_html__('Our Advisors 2', BUNCH_NAME),
					'base' => 'bunch_our_advisors_2',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-users',
					'description' => esc_html__('Show Our Advisors 2.', BUNCH_NAME),
					'params' => array(
						$title,
						$text,
						$number,
						$team_cat,
						$orderby,
						$order,
					),
			);
//Company Overview
$options['bunch_company_overview'] = array(
					'name' => esc_html__('Company Overview', BUNCH_NAME),
					'base' => 'bunch_company_overview',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-users',
					'description' => esc_html__('Show Company Overview.', BUNCH_NAME),
					'params' => array(
						//Tabs Start
						esc_html__( 'General', BUNCH_NAME ) => array(
							$img,
							$title,
							$text,
						),
						//Tabs Start
						esc_html__( 'Stalibilish', BUNCH_NAME ) => array(
							array(
								"type"			=>	"attach_image_url",
								"label"			=>	esc_html__('Image Top', BUNCH_NAME ),
								"name"			=>	"img_top",
								'admin_label' 	=> 	false,
								"description"	=>	esc_html__('Choose Image Top.', BUNCH_NAME )
							),
							array(
								"type"			=>	"attach_image_url",
								"label"			=>	esc_html__('Image Bottom', BUNCH_NAME ),
								"name"			=>	"img_bottom",
								'admin_label' 	=> 	false,
								"description"	=>	esc_html__('Choose Image Bottom.', BUNCH_NAME )
							),
							array(
								"type"			=>	"text",
								"label"			=>	esc_html__('Title', BUNCH_NAME ),
								"name"			=>	"title1",
								"description"	=>	esc_html__('Enter section title.', BUNCH_NAME )
							),
							array(
								"type"			=>	"textarea",
								"label"			=>	esc_html__('Text', BUNCH_NAME ),
								"name"			=>	"text1",
								"description"	=>	esc_html__('Enter section text.', BUNCH_NAME )
							),
							$text_list,
						),
						//Tabs Start
						esc_html__( 'Stability Company', BUNCH_NAME ) => array(
							array(
								"type"			=>	"text",
								"label"			=>	esc_html__('Title', BUNCH_NAME ),
								"name"			=>	"title2",
								"description"	=>	esc_html__('Enter section title.', BUNCH_NAME )
							),
							array(
								"type"			=>	"textarea",
								"label"			=>	esc_html__('Text', BUNCH_NAME ),
								"name"			=>	"text2",
								"description"	=>	esc_html__('Enter section text.', BUNCH_NAME )
							),
						),
					),
			);
//Company History
$options['bunch_company_history'] = array(
					'name' => esc_html__('Company History', BUNCH_NAME),
					'base' => 'bunch_company_history',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-users',
					'description' => esc_html__('Show Company History.', BUNCH_NAME),
					'params' => array(
						$img,
						$title,
						$text,
						array(
							'type' => 'group',
							'label' => esc_html__( 'Company History', BUNCH_NAME ),
							'name' => 'company_history',
							'description' => esc_html__( 'Enter Company History Details.', BUNCH_NAME ),
							'params' => array(
								array(
									"type"			=>	"text",
									"label"			=>	esc_html__('Year', BUNCH_NAME ),
									"name"			=>	"year",
									"description"	=>	esc_html__('Enter section title.', BUNCH_NAME )
								),
								$title,
								$text,
								array(
									"type"			=>	"attach_image_url",
									"label"			=>	esc_html__('Image Left', BUNCH_NAME ),
									"name"			=>	"img_left",
									'admin_label' 	=> 	false,
									"description"	=>	esc_html__('Choose Image Left.', BUNCH_NAME )
								),
								array(
									"type"			=>	"attach_image_url",
									"label"			=>	esc_html__('Image Right', BUNCH_NAME ),
									"name"			=>	"img_right",
									'admin_label' 	=> 	false,
									"description"	=>	esc_html__('Choose Image Right.', BUNCH_NAME )
								),
							),
						),
					),
			);
//Company Career
$options['bunch_company_career'] = array(
					'name' => esc_html__('Company Career', BUNCH_NAME),
					'base' => 'bunch_company_career',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-users',
					'description' => esc_html__('Show Company Career.', BUNCH_NAME),
					'params' => array(
						//Tabs Start
						esc_html__( 'General', BUNCH_NAME ) => array(
							$title,
							$text,
							$text_list,
						),
						//Tabs Start
						esc_html__( 'Open Positions', BUNCH_NAME ) => array(
							array(
								"type"			=>	"text",
								"label"			=>	esc_html__('Title', BUNCH_NAME ),
								"name"			=>	"title1",
								"description"	=>	esc_html__('Enter section title.', BUNCH_NAME )
							),
							array(
								"type"			=>	"text",
								"label"			=>	esc_html__('Download Text', BUNCH_NAME ),
								"name"			=>	"download_text",
								"description"	=>	esc_html__('Enter section Download Text.', BUNCH_NAME )
							),
							$btn_title,
							$btn_link,
							array(
								'type' => 'group',
								'label' => esc_html__( 'Company History', BUNCH_NAME ),
								'name' => 'company_career',
								'description' => esc_html__( 'Enter Company History Details.', BUNCH_NAME ),
								'params' => array(
									$title,
									$text,
								),
							),
						),
					),
			);
//Our Partners
$options['bunch_our_partners'] = array(
					'name' => esc_html__('Our Partners', BUNCH_NAME),
					'base' => 'bunch_our_partners',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-users',
					'description' => esc_html__('Show Our Partners Logo images.', BUNCH_NAME),
					'params' => array(
						$title,
						$text,
						array(
							'type' => 'group',
							'label' => esc_html__( 'Our Partners Logo', BUNCH_NAME ),
							'name' => 'our_partners',
							'description' => esc_html__( 'Enter Our Partners Logo', BUNCH_NAME ),
							'params' => array(
								$title,
								$img,
								$text,
							),
						),
					),
			);
//Services
$options['bunch_services'] = array(
					'name' => esc_html__('Services', BUNCH_NAME),
					'base' => 'bunch_services',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Services.', BUNCH_NAME),
					'params' => array(
						$text_limit,
						$number,
						$services_cat,
						$orderby,
						$order,
					),
			);
//Services Single 1
$options['bunch_services_single_1'] = array(
					'name' => esc_html__('Services Single 1', BUNCH_NAME),
					'base' => 'bunch_services_single_1',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show Services Single 1.', BUNCH_NAME),
					'params' => array(
						esc_html__( 'General', BUNCH_NAME ) => array(
							array(
								"type"			=>	"attach_image_url",
								"label"			=>	esc_html__('Image Left', BUNCH_NAME ),
								"name"			=>	"img_left",
								'admin_label' 	=> 	false,
								"description"	=>	esc_html__('Choose Image Left.', BUNCH_NAME )
							),
							array(
								"type"			=>	"attach_image_url",
								"label"			=>	esc_html__('Image Right', BUNCH_NAME ),
								"name"			=>	"img_right",
								'admin_label' 	=> 	false,
								"description"	=>	esc_html__('Choose Image Right.', BUNCH_NAME )
							),
							$title,
							$text,
						),
						esc_html__( 'How it Work', BUNCH_NAME ) => array(
							array(
								"type"			=>	"text",
								"label"			=>	esc_html__('Title', BUNCH_NAME ),
								"name"			=>	"title2",
								"description"	=>	esc_html__('Enter section title.', BUNCH_NAME )
							),
							array(
								"type"			=>	"textarea",
								"label"			=>	esc_html__('Text', BUNCH_NAME ),
								"name"			=>	"text2",
								"description"	=>	esc_html__('Enter text to show.', BUNCH_NAME )
							),
							array(
								'type' => 'group',
								'label' => esc_html__( 'How it Work', BUNCH_NAME ),
								'name' => 'how_it_work',
								'description' => esc_html__( 'Enter How it Work Details', BUNCH_NAME ),
								'params' => array(
									$title,
									$url,
									$icon,
									$text,
								),
							),
						),
						esc_html__( 'Choose Us', BUNCH_NAME ) => array(
							array(
								"type"			=>	"text",
								"label"			=>	esc_html__('Title', BUNCH_NAME ),
								"name"			=>	"title3",
								"description"	=>	esc_html__('Enter section title.', BUNCH_NAME )
							),
							array(
								"type"			=>	"attach_image_url",
								"label"			=>	esc_html__('Image', BUNCH_NAME ),
								"name"			=>	"img3",
								'admin_label' 	=> 	false,
								"description"	=>	esc_html__('Choose Image.', BUNCH_NAME )
							),
							array(
								'type' => 'group',
								'label' => esc_html__( 'Why Choose Us', BUNCH_NAME ),
								'name' => 'why_choose_us',
								'description' => esc_html__( 'Enter Why Choose Us Details', BUNCH_NAME ),
								'params' => array(
									$title,
									$text,
								),
							),
						),
						esc_html__( 'Awards', BUNCH_NAME ) => array(
							array(
								"type"			=>	"text",
								"label"			=>	esc_html__('Title', BUNCH_NAME ),
								"name"			=>	"title4",
								"description"	=>	esc_html__('Enter section title.', BUNCH_NAME )
							),
							array(
								"type"			=>	"textarea",
								"label"			=>	esc_html__('Text', BUNCH_NAME ),
								"name"			=>	"text4",
								"description"	=>	esc_html__('Enter text to show.', BUNCH_NAME )
							),
							array(
								"type"			=>	"attach_image_url",
								"label"			=>	esc_html__('Image', BUNCH_NAME ),
								"name"			=>	"img4",
								'admin_label' 	=> 	false,
								"description"	=>	esc_html__('Choose Image.', BUNCH_NAME )
							),
						),
					),
			);
//Services Single 2
$options['bunch_services_single_2'] = array(
					'name' => esc_html__('Services Single 2', BUNCH_NAME),
					'base' => 'bunch_services_single_2',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show Services Single 2.', BUNCH_NAME),
					'params' => array(
						esc_html__( 'General', BUNCH_NAME ) => array(
							$img,
							$title,
							$text,
						),
						esc_html__( 'How it Work', BUNCH_NAME ) => array(
							array(
								"type"			=>	"text",
								"label"			=>	esc_html__('Title', BUNCH_NAME ),
								"name"			=>	"title2",
								"description"	=>	esc_html__('Enter section title.', BUNCH_NAME )
							),
							array(
								"type"			=>	"textarea",
								"label"			=>	esc_html__('Text', BUNCH_NAME ),
								"name"			=>	"text2",
								"description"	=>	esc_html__('Enter text to show.', BUNCH_NAME )
							),
							array(
								'type' => 'group',
								'label' => esc_html__( 'How it Work', BUNCH_NAME ),
								'name' => 'how_it_work',
								'description' => esc_html__( 'Enter How it Work Details', BUNCH_NAME ),
								'params' => array(
									$title,
									$url,
									$icon,
									$text,
								),
							),
						),
						esc_html__( 'Choose Us', BUNCH_NAME ) => array(
							array(
								"type"			=>	"text",
								"label"			=>	esc_html__('Title', BUNCH_NAME ),
								"name"			=>	"title3",
								"description"	=>	esc_html__('Enter section title.', BUNCH_NAME )
							),
							array(
								"type"			=>	"attach_image_url",
								"label"			=>	esc_html__('Image', BUNCH_NAME ),
								"name"			=>	"img3",
								'admin_label' 	=> 	false,
								"description"	=>	esc_html__('Choose Image.', BUNCH_NAME )
							),
							array(
								'type' => 'group',
								'label' => esc_html__( 'Why Choose Us', BUNCH_NAME ),
								'name' => 'why_choose_us',
								'description' => esc_html__( 'Enter Why Choose Us Details', BUNCH_NAME ),
								'params' => array(
									$title,
									$text,
								),
							),
						),
						esc_html__( 'Awards', BUNCH_NAME ) => array(
							array(
								"type"			=>	"text",
								"label"			=>	esc_html__('Benefits Title', BUNCH_NAME ),
								"name"			=>	"title5",
								"description"	=>	esc_html__('Enter section title.', BUNCH_NAME )
							),
							array(
								"type"			=>	"textarea",
								"label"			=>	esc_html__('Benefits Text', BUNCH_NAME ),
								"name"			=>	"text5",
								"description"	=>	esc_html__('Enter text to show.', BUNCH_NAME )
							),
							array(
								"type"			=>	"textarea",
								"label"			=>	esc_html__('Benefits Text List', BUNCH_NAME ),
								"name"			=>	"text_list",
								"description"	=>	esc_html__('Enter text listing to show.', BUNCH_NAME )
							),
							array(
								"type"			=>	"text",
								"label"			=>	esc_html__('Award Title', BUNCH_NAME ),
								"name"			=>	"title4",
								"description"	=>	esc_html__('Enter section title.', BUNCH_NAME )
							),
							array(
								"type"			=>	"textarea",
								"label"			=>	esc_html__('Award Text', BUNCH_NAME ),
								"name"			=>	"text4",
								"description"	=>	esc_html__('Enter text to show.', BUNCH_NAME )
							),
							array(
								"type"			=>	"attach_image_url",
								"label"			=>	esc_html__('Award Image', BUNCH_NAME ),
								"name"			=>	"img4",
								'admin_label' 	=> 	false,
								"description"	=>	esc_html__('Choose Image.', BUNCH_NAME )
							),
						),
					),
			);
//Projects 3 Column
$options['bunch_projects_3_column'] = array(
					'name' => esc_html__('Projects 3 Column', BUNCH_NAME),
					'base' => 'bunch_projects_3_column',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show Projects 3 Column.', BUNCH_NAME),
					'params' => array(
						$number,
						$exclude_cats,
						$orderby,
						$order,
					),
			);
//Projects 4 Column
$options['bunch_projects_4_column'] = array(
					'name' => esc_html__('Projects 4 Column', BUNCH_NAME),
					'base' => 'bunch_projects_4_column',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show Projects 4 Column.', BUNCH_NAME),
					'params' => array(
						$number,
						$exclude_cats,
						$orderby,
						$order,
					),
			);
//Projects Fullwidth
$options['bunch_projects_fullwidth'] = array(
					'name' => esc_html__('Projects Fullwidth', BUNCH_NAME),
					'base' => 'bunch_projects_fullwidth',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show Projects Fullwidth.', BUNCH_NAME),
					'params' => array(
						$number,
						$exclude_cats,
						$orderby,
						$order,
					),
			);
//FAQs
$options['bunch_faqs'] = array(
					'name' => esc_html__('FAQs', BUNCH_NAME),
					'base' => 'bunch_faqs',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-question',
					'description' => esc_html__('Show FAQs.', BUNCH_NAME),
					'params' => array(
						$title,
						$text,
						$text_limit,
						$number,
						$faqs_cat,
						$orderby,
						$order,
					),
			);
//FAQs Form
$options['bunch_faqs_form'] = array(
					'name' => esc_html__('FAQs Form', BUNCH_NAME),
					'base' => 'bunch_faqs_form',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show FAQs Form.', BUNCH_NAME),
					'params' => array(
						$contact_title,
						$contact_shortcode,
					),
			);
//Our Team
$options['bunch_our_team'] = array(
					'name' => esc_html__('Our Team', BUNCH_NAME),
					'base' => 'bunch_our_team',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-users',
					'description' => esc_html__('Show Our Team.', BUNCH_NAME),
					'params' => array(
						$title,
						$text,
						$number,
						$team_cat,
						$orderby,
						$order,
					),
			);
//Testimonials 2
$options['bunch_testimonials_2'] = array(
					'name' => esc_html__('Testimonials 2', BUNCH_NAME),
					'base' => 'bunch_testimonials_2',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-briefcase',
					'description' => esc_html__('Show Testimonials 2.', BUNCH_NAME),
					'params' => array(
						$text_limit,
						$number,
						$testimonials_cat,
						$orderby,
						$order,
					),
			);

//Blog Grid
$options['bunch_blog_grid'] = array(
					'name' => esc_html__('Blog Grid', BUNCH_NAME),
					'base' => 'bunch_blog_grid',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Blog Grid.', BUNCH_NAME),
					'params' => array(
						$text_limit,
						$number,
						$cat,
						$orderby,
						$order,
					),
			);
//Contact Us
$options['bunch_contact_us'] = array(
					'name' => esc_html__('Contact Us', BUNCH_NAME),
					'base' => 'bunch_contact_us',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-envelope',
					'description' => esc_html__('Show contact detail.', BUNCH_NAME),
					'params' => array(
						esc_html__( 'General', BUNCH_NAME ) => array(
							$title,
							$text,
							$contact_shortcode,
							$address,
							$phone,
							$email,
						),
					),
			);
//Google Map
$options['bunch_google_map'] = array(
					'name' => esc_html__('Google Map', BUNCH_NAME),
					'base' => 'bunch_google_map',
					'class' => '',
					'category' => esc_html__('Consultox', BUNCH_NAME),
					'icon' => 'fa-envelope',
					'description' => esc_html__('Show Google Map.', BUNCH_NAME),
					'params' => array(
						$latitude,
						$longitude,
						$name,
						$zoom,
						$address,
						$email,
					),
			);
return $options;
